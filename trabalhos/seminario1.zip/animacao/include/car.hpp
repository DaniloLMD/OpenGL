#ifndef __CAR_HPP__
#define __CAR_HPP__

void update_cars();

#endif