#ifndef __WINDMILL_HPP__
#define __WINDMILL_HPP__

#include "point.hpp"

void draw_windmill(Point p, double ang);

void update_windmills();

#endif