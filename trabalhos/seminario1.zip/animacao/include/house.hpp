#ifndef __HOUSE_HPP
#define __HOUSE_HPP

#include "point.hpp"

void draw_house(Point p);

void draw_houses();

#endif
