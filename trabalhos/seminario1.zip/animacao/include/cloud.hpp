#ifndef __CLOUD_HPP__
#define __CLOUD_HPP__

void update_clouds();

#endif